

<?php $__env->startSection('title'); ?>
<?php echo e($property->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
<?php echo e($property->description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pagesheader" style="height: 100px"></div>
    <div class="breadcramb">
        <div class="container">
            <p class="mb-0 text-sm"> Home > Property > <?php echo e($property->name); ?> </p>
        </div>
    </div>
    <div class="container propertyView">
        
        <div class="row py-3 ">
            <div class="col-md-8">
                <h3 class="mb-3"><?php echo e($property->name); ?></h3>
                <div class="property-tags mb-4">
                    <span class="tag"><?php echo e($property->propertyType->property_type); ?></span>
                    <?php if($property->property_listing): ?>
                        <?php $__currentLoopData = explode(',', $property->property_listing); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="tag"><?php echo e(trim($listing)); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="property-info mb-4">
                    <?php if($property->space): ?>
                        <div class="tag">
                            <i class="fa-regular fa-house"></i>
                            Property Space : SFT <?php echo e($property->space); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($property->country_id == 19 && ($property->city || $property->propertyarea)): ?>
                        <div class="tag">
                            <i class="fa-solid fa-location-dot"></i>
                            Property Area : <?php echo e($property->city . ', ' . $property->propertyarea->name); ?>

                        </div>
                    <?php elseif($property->country_id != 19 && ($property->city || $property->state)): ?>
                        <div class="tag">
                            <i class="fa-solid fa-location-dot"></i>
                            Property Area : <?php echo e($property->city . ', ' . $property->state->name); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($property->bedrooms): ?>
                        <div class="tag">
                            <i class="fa-solid fa-bed"></i>
                            Bedrooms : <?php echo e($property->bedrooms); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($property->bathrooms): ?>
                        <div class="tag">
                            <i class="fa-solid fa-sink"></i>
                            Bathrooms : <?php echo e($property->bathrooms); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($property->parking_space): ?>
                        <div class="tag">
                            <i class="fa-solid fa-car"></i>
                            Parking Space : <?php echo e($property->parking_space); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($property->decoration): ?>
                        <div class="tag">
                            <?php if($property->decoration == 'Full Furnished'): ?>
                                <i class="fa-solid fa-couch"></i>
                                Decoration : <?php echo e($property->decoration); ?>

                            <?php else: ?>
                                <i class="fa-solid fa-paint-roller"></i>
                                Decoration : <?php echo e($property->decoration); ?>

                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="swiper mySwiper mb-3">
                    <div class="swiper-wrapper">
                        <?php if($property->featured_image): ?>
                            <div class="swiper-slide">
                                <img class="slider-img" src="<?php echo e(asset($property->featured_image)); ?>" alt="">
                            </div>
                        <?php endif; ?>
                        <?php if($property->images->isNotEmpty()): ?>
                            <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img class="slider-img" src="<?php echo e(asset($images->image)); ?>" alt="">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <hr>
                <div class="py-4">
                    <h4 class="mb-3">Discription :</h4>
                    <?php echo e($property->description); ?>

                </div>
                <hr>
                <div class="py-4">
                    <h4 class="mb-3">Property Features :</h4>
                    <div class="grid-container">
                        <?php if($property->features): ?>
                            <?php $__currentLoopData = $property->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mb-1"><strong> <?php echo e($feature->feature_keys); ?> : </strong> <?php echo e($feature->feature_values); ?> </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
                <div class="py-4">
                    <h4 class="mb-3">Amenities :</h4>
                    <div class="grid-container">
                        <?php if($property->amenities): ?>
                            <?php $__currentLoopData = $property->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mb-1"><i class="fa-solid fa-check-double"></i> <?php echo e($amenity->amenities); ?> </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
            </div>
            <div class="col-md-4">
                <div class="border rounded p-4">
                    <div>
                        <h5>
                            <i class="fa-solid fa-wallet"></i> Price : <span id="pricePerNight"><?php echo e($property->price); ?></span> BDT <sup> (per night)</sup>
                        </h5>
                        <div>
                            <a href="" class="btn btn-primary"><i class="fa-solid fa-envelope"></i> Property Inquiry</a>
                            <a href="" class="btn btn-primary" onclick="print()"><i class="fa-solid fa-print"></i></a>
                        </div>
                        <form id="rentProperty" class="mt-3">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <input type="text" id="rentDateRange" class="form-control" placeholder="Select Booking Dates" readonly>
                            </div>
                            <h6 class="mt-2">
                                Total Price: <span id="totalPrice">0</span> BDT
                            </h6>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fa-regular fa-calendar-check"></i> Book Now
                            </button>
                        </form>
                    </div>
                    <hr>
                    <div>
                        <p>Property Location :</p>
                        <?php
                            use App\Models\District;

                            if ($property->country_id == 19) {
                                $district = District::where('id', $property->property_area_id)->first();
                                $address = $property->road . ', ' . $property->city . ', ' . ($property->propertyarea->name ?? '') . ', ' . ($district->name ?? '') . ', ' . ($property->country->name ?? '');
                            } else {
                                $address = $property->road . ', ' . $property->city . ', ' . ($property->state->name ?? '') . ', ' . ($property->country->name ?? '');
                            }
                        ?>

                        <iframe
                            width="100%"
                            height="400"
                            style="border:0"
                            loading="lazy"
                            allowfullscreen
                            src="https://www.google.com/maps?q=<?php echo e(urlencode($address ?? 'Dhaka, Bangladesh')); ?>&output=embed">
                        </iframe>

                    </div>
                    <hr>
                    <div>
                        <p>Realtor :</p>
                        <div class="row border m-0 rounded p-3">
                            <div class="col-md-4">
                                <img src="<?php echo e(asset('admin-assets/img/assets/1746548373_681a369536d71.png')); ?>" style="width: 100% ;" alt="">
                            </div>
                            <div class="col-md-8">
                                <h4><?php echo e($property->realtor->name); ?></h4>
                                <p class="mb-1">Email : <?php echo e($property->realtor->email); ?></p>
                                <p class="mb-1">Phone : <?php echo e($property->realtor->mobile); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
<script>
        const swiper = new Swiper(".mySwiper", {
            loop: true,
            effect: "slide", // or "fade" for a smoother dissolve effect
            speed: 1500, // 1.5 seconds for smooth sliding
            autoplay: {
              delay: 5000, // 5 seconds before changing slides
              disableOnInteraction: false,
            },
            // autoplay: false,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            
        });
    </script>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    const pricePerNight = parseFloat(document.getElementById('pricePerNight').innerText);
    const totalPriceEl = document.getElementById('totalPrice');
    const dateInput = document.getElementById('rentDateRange');

    // 📅 Fetch booked dates from backend (you’ll return them as array)
    const bookedDates = <?php echo json_encode($bookedDates, 15, 512) ?>; // Example: ["2025-10-25", "2025-10-26", "2025-11-01"]
    const bookingStartDate = "<?php echo e($property->rent_start); ?>"; // e.g. "2025-10-23"

    // ✅ Initialize Flatpickr
    flatpickr("#rentDateRange", {
        mode: "range",
        minDate: bookingStartDate,
        dateFormat: "Y-m-d",
        disable: bookedDates,
        onChange: function(selectedDates) {
            if (selectedDates.length === 2) {
                const diffTime = Math.abs(selectedDates[1] - selectedDates[0]);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // nights
                const total = diffDays * pricePerNight;
                totalPriceEl.innerText = total.toLocaleString();
            } else {
                totalPriceEl.innerText = 0;
            }
        }
    });

    // 🧾 Optional: Prevent form submission for now
    document.getElementById('rentProperty').addEventListener('submit', function(e) {
        e.preventDefault();
        const dateRange = dateInput.value;
        if (!dateRange) {
            toastr.error('Please select booking dates');
            return;
        }
        toastr.success('Booking form ready to submit!');
        // You can now send via AJAX if needed
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\RealEstate\resources\views/frontend/property/viewRent.blade.php ENDPATH**/ ?>