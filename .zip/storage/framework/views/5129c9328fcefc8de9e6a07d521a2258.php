<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Verify Email</title>
</head>
<body style="font-family: Arial, sans-serif;">
    <h2>Hello ,</h2>
    <p>Your verification code is:</p>
    <h1 style="background: #007bff; color: white; padding: 10px; display: inline-block;">
        <?php echo e($code); ?>

    </h1>
    <p>Enter this code on the website to verify your email address.</p>
    <p>Thank you.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\RealEstate\resources\views\emails\verify-register-email.blade.php ENDPATH**/ ?>