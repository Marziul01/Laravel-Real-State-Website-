<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="app-brand-link justify-content-center">
            <img src="<?php echo e(asset($setting->site_logo)); ?>" alt="Logo" class="app-brand-logo demo" height="100%" width="40%" />
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm d-flex align-items-center justify-content-center"></i>
        </a>
    </div>

    <ul class="menu-inner py-1">
        <!-- Dashboards -->

        <li class="menu-item <?php echo e(Route::currentRouteName() == 'admin.dashboard' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>"
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-smile"></i>
                <div class="text-truncate" data-i18n="Email">Dashboard</div>
            </a>
        </li>

        <li class="menu-item  <?php echo e(Route::currentRouteName() == 'property.index' ? 'active open' : ''); ?> <?php echo e(Route::currentRouteName() == 'property.create' ? 'active open' : ''); ?> ">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon1 tf-icons fa-solid fa-user-gear"></i>
                <div class="text-truncate" data-i18n="Dashboards">Rent Property Managment</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'property.index' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('property.index')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="Analytics">Rent Properties</div>
                    </a>
                </li>

                <li class="menu-item <?php echo e(Route::currentRouteName() == 'property.create' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('property.create')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="Analytics">Add New Property </div>
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item  <?php echo e(Route::currentRouteName() == 'property.sell' ? 'active open' : ''); ?> <?php echo e(Route::currentRouteName() == 'sellcreate' ? 'active open' : ''); ?> ">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon1 tf-icons fa-solid fa-user-gear"></i>
                <div class="text-truncate" data-i18n="Dashboards">Sell Property Managment</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php echo e(Route::currentRouteName() == 'property.sell' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('property.sell')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="Analytics">Sell Properties</div>
                    </a>
                </li>

                <li class="menu-item <?php echo e(Route::currentRouteName() == 'sellcreate' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('sellcreate')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="Analytics">Add New Property </div>
                    </a>
                </li>
            </ul>
        </li>

        
        
    </ul>


    

</aside>
<?php /**PATH C:\xampp\htdocs\RealEstate\resources\views\admin\include\sidebar.blade.php ENDPATH**/ ?>