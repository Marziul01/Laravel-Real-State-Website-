<div class="d-flex align-items-center gap-1 cursor-pointer">

    <a href="<?php echo e(route('property.edit', $row->id)); ?>" class="btn btn-sm btn-secondary">
        <i class="bx bx-edit-alt me-1"></i> Edit
    </a>

    <form action="<?php echo e(route('property.destroy', $row->id)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-sm btn-outline-danger delete-confirm">
            <i class="bx bx-trash me-1"></i> Delete
        </button>
    </form>

</div><?php /**PATH C:\xampp\htdocs\RealEstate\resources\views\admin\property\_actions.blade.php ENDPATH**/ ?>