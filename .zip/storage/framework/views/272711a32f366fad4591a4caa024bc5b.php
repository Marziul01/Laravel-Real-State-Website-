<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Password Reset Code</title>
</head>
<body>
    <h2>Hello,</h2>
    <p>You requested to reset your password.</p>
    <p><strong>Your verification code is:</strong></p>
    <h1 style="color: #0a53be;"><?php echo e($code); ?></h1>
    <p>This code will expire soon. If you did not request this, please ignore this message.</p>
    <br>
    <p>Thank you,<br>Your Support Team</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\RealEstate\resources\views\emails\reset_code.blade.php ENDPATH**/ ?>